# Applying Colorverse to the repository

The GitHub connection rejected branch creation with HTTP 403 (`Resource not accessible by integration`), so this package has **not** been pushed and no repository files were changed. Copy `game-086/` into the repository root, then update the following metadata:

## `js/gamedata.js`
Append before the closing array bracket, adapting indentation to nearby entries:
```js
{
  id: 'game-086',
  title: 'Colorverse',
  description: 'A cozy sci-fi and fantasy coloring book. Fill line drawings, collect completed art, save progress, and share PNG creations.',
  icon: '🎨',
  folder: 'game-086',
  version: '1.0.0',
  cssClass: 'colorverse',
  genre: 'cozy',
  tags: [
    { emoji: '🎨', label: 'Coloring' },
    { emoji: '🌙', label: 'Cozy' },
    { emoji: '🚀', label: 'Fantasy & Sci-fi' },
    { emoji: '🖌️', label: 'Canvas 2D' }
  ]
}
```

## `css/styles.css`
Add alongside the other game theme styles:
```css
.game-preview.colorverse,
.carousel-slide-bg.colorverse {
  background: radial-gradient(circle at 50% 35%, rgba(245,168,212,.75), transparent 32%),
              radial-gradient(circle at 78% 70%, rgba(145,224,204,.55), transparent 34%),
              linear-gradient(145deg, #211b3d, #65548c 58%, #d7a8c9);
}
.game-card.colorverse .play-button {
  background: linear-gradient(135deg, #f5a8d4, #cbb2ff 55%, #9ce9d2);
  color: #251b3c;
  box-shadow: 0 0 14px rgba(245,168,212,.4);
}
```

## `README.md`
Add a game-086 row using the same table format as neighboring entries: `Colorverse` — cozy sci-fi/fantasy coloring book, fill line drawings, collect completed art, save and share PNG creations — Canvas 2D.

## `status.md`
Add a game-086 row noting the three generated line-art pages, tap-to-fill, pastel palette, undo/reset, guarded localStorage, collection gallery and PNG sharing. Mark browser/mobile testing as pending.

## `CHANGELOG.md`
Under `## [Unreleased]`, add: `- **Colorverse** (game-086) v1.0.0: a cozy sci-fi/fantasy coloring studio with three generated line drawings, region fills, a pastel palette, a personal collection and PNG sharing.`

## Docs
Append a note to `docs/generic/learnings.md`: Canvas `Path2D` can provide both rendering and point-in-region hit testing for compact coloring-book art; stable region IDs make saves compact and robust. Update `docs/README.md` if its generic-learnings summary is maintained manually.
